import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/worker.dart';
import 'new_shift_screen.dart';
import 'workers_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<ShiftResult> _shifts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadShifts();
  }

  Future<void> _loadShifts() async {
    setState(() => _loading = true);
    try {
      final shifts = await ApiService.getShifts();
      setState(() { _shifts = shifts; _loading = false; });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('שגיאה: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  Future<void> _deleteShift(int id) async {
    await ApiService.deleteShift(id);
    _loadShifts();
  }

  // ── Supplement breakdown popup ────────────────────────────────────────────
  void _showSupplementBreakdown(BuildContext context, WorkerResult w) {
    final gold = Theme.of(context).colorScheme.primary;
    final bool hasGap = w.hourlyGap > 0;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1C1C1E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.calculate_outlined, color: gold, size: 20),
            const SizedBox(width: 8),
            Text('חישוב השלמה — ${w.name}',
                style: TextStyle(color: gold, fontSize: 16)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _breakdownRow('טיפים שקיבל', '₪${w.tipAmount.toStringAsFixed(2)}', Colors.white70),
            _breakdownRow('שעות עבודה', '${w.hoursWorked.toStringAsFixed(2)} שעות', Colors.white70),
            _breakdownRow('טיפ לשעה', '₪${w.tipPerHour.toStringAsFixed(2)}', Colors.white70),
            const Divider(color: Colors.white12, height: 20),
            _breakdownRow('שכר מינימום', '₪${w.minHourly.toStringAsFixed(2)}/שעה', Colors.white70),
            _breakdownRow('השלמה בסיסית', '₪${w.baseSupplement.toStringAsFixed(2)}', Colors.white70),
            const Divider(color: Colors.white12, height: 20),
            if (hasGap) ...[
              _breakdownRow(
                'פער שעתי',
                '₪${w.minHourly.toStringAsFixed(2)} - ₪${w.tipPerHour.toStringAsFixed(2)} = ₪${w.hourlyGap.toStringAsFixed(2)}/שעה',
                Colors.orangeAccent,
              ),
              _breakdownRow(
                'תוספת מינימום',
                '₪${w.hourlyGap.toStringAsFixed(2)} × ${w.hoursWorked.toStringAsFixed(2)} = ₪${(w.hourlyGap * w.hoursWorked).toStringAsFixed(2)}',
                Colors.orangeAccent,
              ),
              _breakdownRow(
                'השלמה סופית',
                '₪${w.baseSupplement.toStringAsFixed(2)} + ₪${(w.hourlyGap * w.hoursWorked).toStringAsFixed(2)} = ₪${w.supplement.toStringAsFixed(2)}',
                gold,
                bold: true,
              ),
            ] else ...[
              _breakdownRow(
                'השלמה סופית',
                '₪${w.supplement.toStringAsFixed(2)} (ללא תוספת מינימום)',
                gold,
                bold: true,
              ),
            ],
            const Divider(color: Colors.white12, height: 20),
            _breakdownRow(
              'סה"כ לעובד',
              '₪${w.tipAmount.toStringAsFixed(2)} + ₪${w.supplement.toStringAsFixed(2)} = ₪${w.total.toStringAsFixed(2)}',
              gold,
              bold: true,
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('סגור'),
          ),
        ],
      ),
    );
  }

  Widget _breakdownRow(String label, String value, Color valueColor, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 13)),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.left,
              style: TextStyle(
                color: valueColor,
                fontSize: 13,
                fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final gold = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        title: const Text('🍸 מפצל טיפים'),
        actions: [
          IconButton(
            icon: const Icon(Icons.people),
            tooltip: 'ניהול עובדים',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WorkersScreen()),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NewShiftScreen()),
          );
          _loadShifts();
        },
        backgroundColor: gold,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: const Text('משמרת חדשה',
            style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _shifts.isEmpty
              ? _emptyState()
              : RefreshIndicator(
                  onRefresh: _loadShifts,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                    itemCount: _shifts.length,
                    itemBuilder: (_, i) => _shiftCard(_shifts[i]),
                  ),
                ),
    );
  }

  // ── Empty state ───────────────────────────────────────────────────────────

  Widget _emptyState() => Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.nightlife, size: 80, color: Colors.white24),
            const SizedBox(height: 16),
            const Text('אין משמרות עדיין',
                style: TextStyle(color: Colors.white54, fontSize: 18)),
            const SizedBox(height: 8),
            const Text('לחץ + כדי להוסיף משמרת',
                style: TextStyle(color: Colors.white38, fontSize: 14)),
          ],
        ),
      );

  // ── Shift card ────────────────────────────────────────────────────────────

  Widget _shiftCard(ShiftResult shift) {
    final gold = Theme.of(context).colorScheme.primary;
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header row ──
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(shift.date,
                    style: TextStyle(
                        color: gold,
                        fontWeight: FontWeight.bold,
                        fontSize: 16)),
                IconButton(
                  icon: const Icon(Icons.delete_outline,
                      color: Colors.red, size: 20),
                  onPressed: () => _confirmDelete(shift.id),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // ── Stats row ──
            Row(
              children: [
                _statChip('סה"כ טיפים',
                    '₪${shift.totalAmount.toStringAsFixed(0)}', gold),
                const SizedBox(width: 8),
                _statChip('טיפ לשעה',
                    '₪${shift.hourlyRate.toStringAsFixed(1)}', Colors.white70),
                const SizedBox(width: 8),
                _statChip('שעות סה"כ',
                    shift.totalHours.toStringAsFixed(1), Colors.white70),
              ],
            ),
            const SizedBox(height: 12),

            // ── Workers table ──
            _workersTable(shift.workers),

            // ── Tap hint ──
            const SizedBox(height: 6),
            Row(
              children: const [
                Icon(Icons.touch_app, size: 12, color: Colors.white24),
                SizedBox(width: 4),
                Text('לחץ על ההשלמה לפירוט החישוב',
                    style: TextStyle(color: Colors.white24, fontSize: 11)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Stat chip ─────────────────────────────────────────────────────────────

  Widget _statChip(String label, String value, Color color) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF2C2C2E),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            children: [
              Text(value,
                  style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                      fontSize: 15)),
              const SizedBox(height: 2),
              Text(label,
                  style: const TextStyle(
                      color: Colors.white38, fontSize: 11)),
            ],
          ),
        ),
      );

  // ── Workers table ─────────────────────────────────────────────────────────

  Widget _workersTable(List<WorkerResult> workers) {
    return Table(
      columnWidths: const {
        0: FlexColumnWidth(2),   // שם
        1: FlexColumnWidth(1.3), // כניסה
        2: FlexColumnWidth(1.3), // יציאה
        3: FlexColumnWidth(1.3), // שעות
        4: FlexColumnWidth(2),   // השלמה (tappable)
        5: FlexColumnWidth(2),   // סה"כ
      },
      children: [
        // Header row
        TableRow(
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: Colors.white12)),
          ),
          children: ['שם', 'כניסה', 'יציאה', 'שעות', 'השלמה', 'סה"כ ₪']
              .map((h) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Text(h,
                        style: const TextStyle(
                            color: Colors.white38, fontSize: 11),
                        textAlign: TextAlign.center),
                  ))
              .toList(),
        ),
        // Data rows
        ...workers.map((w) => TableRow(
              children: [
                _cell(w.name, bold: true),
                _cell(w.startTime),
                _cell(w.endTime),
                _cell(w.hoursWorked.toStringAsFixed(1)),
                // Tappable supplement cell
                _supplementCell(w),
                _cell('₪${w.total.toStringAsFixed(0)}',
                    color: Theme.of(context).colorScheme.primary),
              ],
            )),
      ],
    );
  }

  // ── Supplement cell — tappable ────────────────────────────────────────────

  Widget _supplementCell(WorkerResult w) {
    final bool hasGap = w.hourlyGap > 0;
    return GestureDetector(
      onTap: () => _showSupplementBreakdown(context, w),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '₪${w.supplement.toStringAsFixed(0)}',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: hasGap ? Colors.orangeAccent : Colors.white70,
                fontSize: 13,
                fontWeight: hasGap ? FontWeight.bold : FontWeight.normal,
              ),
            ),
            const SizedBox(width: 2),
            Icon(Icons.info_outline,
                size: 11,
                color: hasGap ? Colors.orangeAccent : Colors.white24),
          ],
        ),
      ),
    );
  }

  // ── Regular cell ──────────────────────────────────────────────────────────

  Widget _cell(String text, {bool bold = false, Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: color ?? Colors.white70,
            fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            fontSize: 13,
          ),
        ),
      );

  // ── Delete confirmation ───────────────────────────────────────────────────

  void _confirmDelete(int id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('מחיקת משמרת'),
        content: const Text('האם למחוק את המשמרת?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('ביטול'),
          ),
          TextButton(
            onPressed: () { Navigator.pop(context); _deleteShift(id); },
            child: const Text('מחק', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
